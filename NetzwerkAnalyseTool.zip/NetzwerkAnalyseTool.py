import tkinter as tk
from tkinter import ttk, filedialog, messagebox
import subprocess
import socket
import re
import csv
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading

CREATE_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# --- Lokale OUI-Datenbank
oui_database_local = {
    "00:41:0e": "MediaTek", "d4:4f:67": "TP-Link", "b0:ec:dd": "Intel",
    "fc:ec:da": "Xiaomi", "60:38:e0": "Apple", "f4:09:d8": "Samsung",
    "a4:5e:60": "Cisco", "e4:8d:8c": "AVM", "3c:5a:b4": "Huawei", "70:3a:cb": "Microsoft"
}
oui_database = oui_database_local

def load_oui_database():
    try:
        url = "http://standards-oui.ieee.org/oui/oui.csv"
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        decoded = response.content.decode("utf-8")
        reader = csv.reader(decoded.splitlines())
        return {row[1].strip().lower().replace("-", ":"): row[2].strip() for row in reader if len(row) >= 2}
    except Exception:
        return None

def reload_oui_database():
    global oui_database
    db = load_oui_database()
    label_oui_status.config(text="✅ OUI-Datenbank erfolgreich geladen." if db else "❌ Fehler beim Laden der OUI-Datenbank.")
    if db: oui_database = db

# --- Portscanner Tab ---
class PortScannerTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.build_ui()

    def build_ui(self):
        frm_input = ttk.LabelFrame(self, text="Scan-Einstellungen", padding=10)
        frm_input.pack(fill="x", padx=10, pady=10)

        ttk.Label(frm_input, text="Ziel-IP / Hostname:").grid(row=0, column=0, sticky="w")
        self.entry_target = ttk.Entry(frm_input, width=30)
        self.entry_target.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(frm_input, text="Portbereich:").grid(row=1, column=0, sticky="w")
        port_frame = ttk.Frame(frm_input)
        port_frame.grid(row=1, column=1, sticky="w", padx=5)

        self.entry_start = ttk.Entry(port_frame, width=8)
        self.entry_start.insert(0, "1")
        self.entry_start.pack(side="left")

        ttk.Label(port_frame, text="bis").pack(side="left", padx=5)

        self.entry_end = ttk.Entry(port_frame, width=8)
        self.entry_end.insert(0, "1024")
        self.entry_end.pack(side="left")

        self.scan_btn = ttk.Button(frm_input, text="Scan starten", command=self.start_scan)
        self.scan_btn.grid(row=2, column=0, columnspan=2, pady=10)

        self.tree = ttk.Treeview(self, columns=("port", "status", "service"), show="headings", height=15)
        self.tree.heading("port", text="Port")
        self.tree.heading("status", text="Status")
        self.tree.heading("service", text="Dienst")

        self.tree.column("port", width=80)
        self.tree.column("status", width=100)
        self.tree.column("service", width=150)

        self.tree.pack(fill="both", expand=True, padx=10, pady=10)

    def start_scan(self):
        target = self.entry_target.get().strip()
        try:
            socket.gethostbyname(target)
        except:
            messagebox.showerror("Fehler", "Ungültiger Hostname oder IP-Adresse.")
            return

        try:
            port_start = int(self.entry_start.get())
            port_end = int(self.entry_end.get())
            assert 0 <= port_start <= 65535 and 0 <= port_end <= 65535 and port_start <= port_end
        except:
            messagebox.showerror("Fehler", "Ungültiger Portbereich.")
            return

        self.tree.delete(*self.tree.get_children())
        self.scan_btn.config(state="disabled")
        threading.Thread(target=self.scan_ports, args=(target, port_start, port_end), daemon=True).start()

    def scan_ports(self, target, start, end):
        for port in range(start, end + 1):
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.5)
                result = sock.connect_ex((target, port))
                if result == 0:
                    try:
                        service = socket.getservbyport(port)
                    except:
                        service = "Unbekannt"
                    self.tree.insert("", "end", values=(port, "Offen", service))
        self.scan_btn.config(state="normal")

# --- DNS/WHOIS Tab ---
class DNSWhoisTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.build_ui()

    def build_ui(self):
        frm_input = ttk.LabelFrame(self, text="DNS/WHOIS-Abfrage", padding=10)
        frm_input.pack(fill="x", padx=10, pady=10)

        ttk.Label(frm_input, text="IP oder Domain:").grid(row=0, column=0, sticky="w")
        self.entry_target = ttk.Entry(frm_input, width=40)
        self.entry_target.grid(row=0, column=1, padx=5, pady=5)

        self.btn_query = ttk.Button(frm_input, text="Abfrage starten", command=self.start_query)
        self.btn_query.grid(row=1, column=0, columnspan=2, pady=10)

        self.text_result = tk.Text(self, height=12, wrap="word")
        self.text_result.pack(fill="both", expand=True, padx=10, pady=10)

    def start_query(self):
        target = self.entry_target.get().strip()
        if not target:
            messagebox.showerror("Fehler", "Bitte eine IP-Adresse oder Domain eingeben.")
            return

        self.text_result.delete(1.0, tk.END)
        self.btn_query.config(state="disabled")
        self.text_result.insert(tk.END, "Abfrage läuft...\n")

        def do_query():
            try:
                # DNS Auflösung
                try:
                    ip = socket.gethostbyname(target)
                    host = target
                    self.text_result.insert(tk.END, f"DNS: {host} → {ip}\n")
                except Exception as e:
                    ip = None
                    self.text_result.insert(tk.END, f"DNS-Auflösung fehlgeschlagen: {e}\n")

                if ip is None:
                    # Versuche IP als Hostname aufzulösen
                    try:
                        host = socket.gethostbyaddr(target)[0]
                        self.text_result.insert(tk.END, f"Reverse DNS: {target} → {host}\n")
                    except Exception as e:
                        self.text_result.insert(tk.END, f"Reverse DNS fehlgeschlagen: {e}\n")

                # WHOIS Abfrage
                import whois
                try:
                    w = whois.whois(target)
                    self.text_result.insert(tk.END, "\nWHOIS Daten:\n")
                    for k, v in w.items():
                        self.text_result.insert(tk.END, f"{k}: {v}\n")
                except Exception as e:
                    self.text_result.insert(tk.END, f"\nWHOIS-Abfrage fehlgeschlagen: {e}\n")

            except Exception as e:
                self.text_result.insert(tk.END, f"\nFehler: {e}\n")
            finally:
                self.btn_query.config(state="normal")

        threading.Thread(target=do_query, daemon=True).start()

# --- GUI Setup
root = tk.Tk()
root.title("Hacktool – Netzwerk, WLAN, Geräte + Portscanner + DNS/WHOIS")
root.geometry("1200x700")
tabs = ttk.Notebook(root)
tabs.pack(fill="both", expand=True)

# ---------------------- WLAN Scanner Tab ----------------------
tab_wlan = ttk.Frame(tabs)
tabs.add(tab_wlan, text="WLAN-Scanner")

def scan_wifi_networks_flat():
    try:
        output = subprocess.check_output(["netsh", "wlan", "show", "networks", "mode=bssid"], encoding="cp850", errors="ignore")
        lines = output.splitlines()
        results, ssid, auth, current = [], "", "", {}
        for line in lines:
            line = line.strip()
            if line.startswith("SSID") and " : " in line:
                ssid = line.split(" : ", 1)[1]
            elif line.startswith("Authentifizierung"):
                auth = line.split(":", 1)[1].strip()
            elif line.startswith("BSSID"):
                if current: results.append(current)
                current = {"SSID": ssid, "Authentifizierung": auth}
                current["BSSID"] = line.split(":", 1)[1].strip()
            elif line.startswith("Signal"):
                current["Signal"] = line.split(":", 1)[1].strip()
            elif line.startswith("Funktyp"):
                current["Funktyp"] = line.split(":", 1)[1].strip()
            elif line.startswith("Band"):
                current["Band"] = line.split(":", 1)[1].strip()
            elif line.startswith("Kanal"):
                current["Kanal"] = line.split(":", 1)[1].strip()
            elif line.startswith("Basisraten"):
                current["Basisraten"] = line.split(":", 1)[1].strip()
            elif line.startswith("Andere Raten"):
                current["Andere Raten"] = line.split(":", 1)[1].strip()
        if current: results.append(current)
        return results
    except: return []

columns_wlan = ["SSID", "BSSID", "Signal", "Kanal", "Funktyp", "Band", "Authentifizierung", "Basisraten", "Andere Raten"]
frame_wlan = ttk.Frame(tab_wlan)
frame_wlan.pack(fill="both", expand=True, padx=5, pady=5)
tree_wlan = ttk.Treeview(frame_wlan, columns=columns_wlan, show="headings")
for col in columns_wlan:
    tree_wlan.heading(col, text=col)
    tree_wlan.column(col, width=100)
tree_wlan.pack(side="left", fill="both", expand=True)
ttk.Scrollbar(frame_wlan, orient="vertical", command=tree_wlan.yview).pack(side="right", fill="y")
def update_wifi_tree():
    tree_wlan.delete(*tree_wlan.get_children())
    for row in scan_wifi_networks_flat():
        tree_wlan.insert("", "end", values=[row.get(c, "") for c in columns_wlan])
ttk.Button(tab_wlan, text="WLAN-Scan starten", command=update_wifi_tree).pack(pady=5)

# ---------------------- Netzwerkscanner Tab ----------------------
tab_net = ttk.Frame(tabs)
tabs.add(tab_net, text="Netzwerkscanner")

def get_ipv4_prefix():
    try:
        ipconfig = subprocess.check_output("ipconfig", encoding="cp850", errors="ignore")
        match = re.search(r"IPv4-Adresse[^\d]+(\d+\.\d+\.\d+)\.\d+", ipconfig)
        return match.group(1) + "." if match else socket.gethostbyname(socket.gethostname()).rsplit(".", 1)[0] + "."
    except: return "192.168.0."

def stabile_ping_and_resolve(ip):
    try:
        subprocess.run(["ping", "-n", "1", "-w", "300", ip], stdout=subprocess.DEVNULL,
                       creationflags=CREATE_NO_WINDOW)
        hostname = socket.gethostbyaddr(ip)[0] if socket.gethostbyaddr(ip) else "Unbekannt"
        return {"IP": ip, "Hostname": hostname}
    except: return None

def scan_network(callback_update, callback_done):
    prefix = get_ipv4_prefix()
    ips = [prefix + str(i) for i in range(1, 255)]
    found = []
    with ThreadPoolExecutor(max_workers=50) as ex:
        futures = {ex.submit(stabile_ping_and_resolve, ip): ip for ip in ips}
        for i, f in enumerate(as_completed(futures), 1):
            r = f.result()
            if r: found.append(r)
            callback_update(i, len(ips))
    callback_done(found)

columns_net = ["IP", "Hostname"]
tree_net = ttk.Treeview(tab_net, columns=columns_net, show="headings")
for col in columns_net:
    tree_net.heading(col, text=col)
    tree_net.column(col, width=150)
tree_net.pack(fill="both", expand=True)
progress_net = ttk.Progressbar(tab_net, length=400, mode="determinate")
progress_net.pack()
label_net = ttk.Label(tab_net, text="Bereit.")
label_net.pack()

def start_net_scan():
    tree_net.delete(*tree_net.get_children())
    progress_net["value"] = 0
    label_net.config(text="Scan läuft...")

    def update(done, total):
        progress_net["value"] = (done / total) * 100
        label_net.config(text=f"Scan: {done}/{total}")

    def done(results):
        for dev in results:
            tree_net.insert("", "end", values=(dev["IP"], dev["Hostname"]))
        label_net.config(text="Scan abgeschlossen.")

    root.after(100, lambda: scan_network(update, done))
ttk.Button(tab_net, text="Netzwerkscan starten", command=start_net_scan).pack(pady=5)

# ---------------------- Geräteübersicht Tab ----------------------
tab_dev = ttk.Frame(tabs)
tabs.add(tab_dev, text="Geräteübersicht")

def resolve_device(ip):
    try:
        subprocess.run(["ping", "-n", "1", "-w", "300", ip], stdout=subprocess.DEVNULL,
                       creationflags=CREATE_NO_WINDOW)
        try: hostname = socket.gethostbyaddr(ip)[0]
        except: hostname = "Unbekannt"
        mac = "unbekannt"
        arp = subprocess.check_output("arp -a", encoding="cp850", errors="ignore")
        for line in arp.splitlines():
            if ip in line:
                match = re.search(r"([0-9a-fA-F]{2}[:-]){5}[0-9a-fA-F]{2}", line)
                if match: mac = match.group(0).lower(); break
        hersteller = "Unbekannt"
        if mac != "unbekannt": hersteller = oui_database.get(mac[:8].replace("-", ":"), "Unbekannt")
        return {"IP": ip, "Hostname": hostname, "MAC": mac, "Hersteller": hersteller}
    except: return None

def scan_devices(callback_update, callback_done):
    prefix = get_ipv4_prefix()
    ips = [prefix + str(i) for i in range(1, 255)]
    found = []
    with ThreadPoolExecutor(max_workers=50) as ex:
        futures = {ex.submit(resolve_device, ip): ip for ip in ips}
        for i, f in enumerate(as_completed(futures), 1):
            r = f.result()
            if r: found.append(r)
            callback_update(i, len(ips))
    callback_done(found)

columns_dev = ["IP", "Hostname", "MAC", "Hersteller"]
tree_dev = ttk.Treeview(tab_dev, columns=columns_dev, show="headings")
for col in columns_dev:
    tree_dev.heading(col, text=col)
    tree_dev.column(col, width=140)
tree_dev.pack(fill="both", expand=True)
progress_dev = ttk.Progressbar(tab_dev, length=400, mode="determinate")
progress_dev.pack()
label_dev = ttk.Label(tab_dev, text="Bereit.")
label_dev.pack()
devices_data = []

def start_device_scan():
    global devices_data
    tree_dev.delete(*tree_dev.get_children())
    progress_dev["value"] = 0
    label_dev.config(text="Scan läuft...")

    def update(done, total):
        progress_dev["value"] = (done / total) * 100
        label_dev.config(text=f"Scan: {done}/{total}")

    def done(results):
        devices_data[:] = results
        for dev in results:
            tree_dev.insert("", "end", values=[dev[c] for c in columns_dev])
        label_dev.config(text="Fertig.")

    root.after(100, lambda: scan_devices(update, done))
ttk.Button(tab_dev, text="Gerätescan starten", command=start_device_scan).pack(pady=5)

def export_to_csv():
    if not devices_data: return
    path = filedialog.asksaveasfilename(defaultextension=".csv", filetypes=[("CSV", "*.csv")])
    if path:
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=columns_dev)
            writer.writeheader()
            writer.writerows(devices_data)
ttk.Button(tab_dev, text="CSV exportieren", command=export_to_csv).pack(pady=2)

# --- OUI-Datenbank-Button unten
frame_oui = ttk.Frame(root)
frame_oui.pack(pady=5)
ttk.Button(frame_oui, text="OUI-Datenbank aktualisieren", command=reload_oui_database).pack(side="left", padx=5)
label_oui_status = ttk.Label(frame_oui, text="📄 Verwende lokale OUI-Datenbank.", padding=5)
label_oui_status.pack(side="left")

# --- Portscanner Tab hinzufügen
tab_port = PortScannerTab(tabs)
tabs.add(tab_port, text="Portscanner")

# --- DNS/WHOIS Tab hinzufügen
tab_dnswhois = DNSWhoisTab(tabs)
tabs.add(tab_dnswhois, text="DNS/WHOIS-Abfrage")

root.mainloop()

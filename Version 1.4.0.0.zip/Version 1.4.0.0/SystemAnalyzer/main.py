import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import platform
import subprocess
import os
import psutil
import threading
import time
import traceback


def log_error(e):
    with open("error.log", "a", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%d %H:%M:%S") + "\n")
        f.write(traceback.format_exc())
        f.write("\n\n")

def get_bios_version():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "(Get-CimInstance -ClassName Win32_BIOS).SMBIOSBIOSVersion"],
                text=True, timeout=3).strip()
        else:
            output = subprocess.check_output(['dmidecode', '-s', 'bios-version'], text=True, timeout=3).strip()
        return output
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_gpu_info():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "Get-WmiObject win32_VideoController | Select-Object -ExpandProperty Name"],
                text=True, timeout=3).strip()
        else:
            output = subprocess.check_output(['lspci'], text=True, timeout=3)
            lines = [line for line in output.split('\n') if 'VGA' in line or '3D' in line]
            output = "\n".join(lines)
        return output
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_ram_info():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "(Get-CimInstance -ClassName Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB"],
                text=True, timeout=3).strip()
            return f"{float(output):.2f} GB"
        else:
            output = subprocess.check_output(['grep', 'MemTotal', '/proc/meminfo'], text=True).strip()
            kb = int(output.split()[1])
            return f"{kb / 1024 / 1024:.2f} GB"
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_mainboard_info():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "(Get-WmiObject win32_baseboard).Product"],
                text=True, timeout=3).strip()
        else:
            output = subprocess.check_output(['cat', '/sys/devices/virtual/dmi/id/board_name'], text=True).strip()
        return output
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_network_info():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "(Get-NetAdapter | Where-Object { $_.Status -eq 'Up' }).Name"],
                text=True, timeout=3).strip()
        else:
            output = subprocess.check_output(['ip', 'link'], text=True).strip()
        return output
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_windows_edition():
    try:
        if platform.system() == "Windows":
            output = subprocess.check_output(
                ['powershell', '-Command', "(Get-ItemProperty \"HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\").EditionID"],
                text=True, timeout=3).strip()
            return output
        else:
            return "Linux"
    except Exception as e:
        log_error(e)
        return "Unknown"

def get_system_info():
    return {
        "Betriebssystem": f"{platform.system()} {platform.release()} ({get_windows_edition()})",
        "Prozessor": platform.processor(),
        "Architektur": platform.machine(),
        "Python-Version": platform.python_version(),
        "BIOS-Version": get_bios_version(),
        "GPU": get_gpu_info(),
        "RAM": get_ram_info(),
        "Mainboard": get_mainboard_info(),
        "Netzwerkadapter": get_network_info()
    }

def export_info(info):
    file_path = filedialog.asksaveasfilename(defaultextension=".txt",
                                             filetypes=[("Textdateien", "*.txt")],
                                             title="Systeminfo exportieren")
    if file_path:
        with open(file_path, 'w', encoding='utf-8') as f:
            for key, value in info.items():
                f.write(f"{key}: {value}\n")
        messagebox.showinfo("Exportiert", f"Daten wurden in {file_path} gespeichert.")

def update_usage(cpu_bar, ram_bar, disk_bar, net_label):
    def refresh():
        old_sent = psutil.net_io_counters().bytes_sent
        old_recv = psutil.net_io_counters().bytes_recv
        while True:
            try:
                cpu = psutil.cpu_percent()
                ram = psutil.virtual_memory().percent
                disk = psutil.disk_usage('/' if platform.system() != 'Windows' else 'C:\\').percent
                new_sent = psutil.net_io_counters().bytes_sent
                new_recv = psutil.net_io_counters().bytes_recv
                net_speed = f"Senden: {(new_sent - old_sent) / 1024:.1f} KB/s | Empfangen: {(new_recv - old_recv) / 1024:.1f} KB/s"
                old_sent, old_recv = new_sent, new_recv

                cpu_bar['value'] = cpu
                ram_bar['value'] = ram
                disk_bar['value'] = disk
                net_label.config(text=net_speed)

                time.sleep(1)
            except Exception as e:
                log_error(e)
                break

    threading.Thread(target=refresh, daemon=True).start()

def create_gui():
    root = tk.Tk()
    root.title("System Informations Tool by Yanis")
    root.geometry("600x450")

    style = ttk.Style()
    try:
        style.theme_use('clam')
    except:
        style.theme_use(style.theme_names()[0])

    style.configure("blue.Horizontal.TProgressbar", troughcolor='white', background='blue')

    notebook = ttk.Notebook(root)
    notebook.pack(expand=True, fill='both')

    tab_sys = ttk.Frame(notebook)
    tab_usage = ttk.Frame(notebook)
    notebook.add(tab_sys, text='Systeminfo')
    notebook.add(tab_usage, text='Systemauslastung')

    info = get_system_info()
    for idx, (key, value) in enumerate(info.items()):
        ttk.Label(tab_sys, text=f"{key}:", font=("Segoe UI", 10, "bold")).grid(row=idx, column=0, sticky='w', padx=10, pady=4)
        ttk.Label(tab_sys, text=value, wraplength=400).grid(row=idx, column=1, sticky='w')

    button_frame = ttk.Frame(tab_sys)
    button_frame.grid(row=len(info), column=0, columnspan=2, pady=10)

    export_btn = ttk.Button(button_frame, text="Exportieren als TXT", command=lambda: export_info(info))
    export_btn.pack()

    usage_labels = ['CPU-Auslastung', 'RAM-Auslastung', 'Datenträger-Auslastung']
    bars = []
    for i, label in enumerate(usage_labels):
        ttk.Label(tab_usage, text=label + ':').grid(row=i, column=0, sticky='w', padx=10, pady=10)
        bar = ttk.Progressbar(tab_usage, length=400, maximum=100, style="blue.Horizontal.TProgressbar")
        bar.grid(row=i, column=1, padx=10, pady=10)
        bars.append(bar)

    ttk.Label(tab_usage, text="Netzwerk (momentan):").grid(row=3, column=0, sticky='w', padx=10, pady=10)
    net_label = ttk.Label(tab_usage, text="...", font=("Segoe UI", 9))
    net_label.grid(row=3, column=1, sticky='w')

    update_usage(bars[0], bars[1], bars[2], net_label)

    root.mainloop()

if __name__ == "__main__":
    try:
        create_gui()
    except Exception as e:
        log_error(e)
        try:
            root = tk.Tk()
            root.withdraw()
            messagebox.showerror("Fehler", "Ein unerwarteter Fehler ist aufgetreten.\nDetails siehe error.log")
        except:
            pass

import os, sys, time, threading, platform, psutil
import tkinter as tk
from tkinter import ttk

def update_stats(cpu_var, ram_var, disk_var, net_var):
    prev = psutil.net_io_counters()
    while True:
        cpu_var.set(psutil.cpu_percent())
        ram_var.set(psutil.virtual_memory().percent)
        disk_var.set(psutil.disk_usage("C:\\" if platform.system()=="Windows" else "/").percent)
        now = psutil.net_io_counters()
        net_var.set(f"↑ {(now.bytes_sent - prev.bytes_sent)/1024:.1f} KB/s  ↓ {(now.bytes_recv - prev.bytes_recv)/1024:.1f} KB/s")
        prev = now
        time.sleep(1)

def main():
    root = tk.Tk()
    root.title("G4MEOVER")
    if getattr(sys, "_MEIPASS", None):
        ico_path = os.path.join(sys._MEIPASS, "logo.ico")
    else:
        ico_path = os.path.join(os.path.dirname(__file__), "logo.ico")
    if os.path.exists(ico_path):
        try:
            root.iconbitmap(default=ico_path)
        except Exception:
            pass

    root.geometry("700x290")
    root.resizable(False, False)

    cpu = tk.DoubleVar(); ram = tk.DoubleVar(); disk = tk.DoubleVar(); net = tk.StringVar(value="...")

    frm = ttk.Frame(root, padding=10)
    frm.pack(expand=True, fill="both")

    for i, (lbl, var) in enumerate([("CPU‑Auslastung", cpu), ("RAM‑Auslastung", ram), ("Datenträger‑Auslastung", disk)]):
        ttk.Label(frm, text=lbl+":").grid(row=i, column=0, sticky="w", padx=5, pady=3)
        ttk.Progressbar(frm, variable=var, maximum=100, length=500).grid(row=i, column=1, pady=3, sticky="w")

    ttk.Label(frm, text="Netzwerk:").grid(row=3, column=0, sticky="w", padx=5, pady=3)
    ttk.Label(frm, textvariable=net).grid(row=3, column=1, sticky="w", pady=3, padx=5)

    threading.Thread(target=update_stats, args=(cpu, ram, disk, net), daemon=True).start()
    root.mainloop()

if __name__ == "__main__":
    main()
